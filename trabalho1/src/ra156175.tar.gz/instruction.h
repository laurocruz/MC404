#include "config.h"

void manage_instruction(BYTE ** map, char * op, unsigned short int pos[], bool rot); 
int instruction_type(char * inst); 

