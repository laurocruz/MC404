#include "config.h"

void manage_label(char * label, unsigned short int pos[]);

